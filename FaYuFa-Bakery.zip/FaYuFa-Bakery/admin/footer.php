<footer style="background-color: gray;padding: 1px;" class="print">
	<h5 class="text-center">Copyright&copy; Yugha Putra Imanudin</h5>
</footer>
</body>
</html>