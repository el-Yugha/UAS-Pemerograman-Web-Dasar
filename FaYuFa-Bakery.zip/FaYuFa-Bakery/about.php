<?php 
	include 'header.php';
 ?>


<div class="container" style="padding-bottom: 300px;">
	<h2 style=" width: 100%; border-bottom: 4px solid #ff8680"><b>Tentang Kami</b></h2>
	<p class="text-justify">FaYuFa cake & Bakery adalah toko roti Indonesia ternama dengan 1 cabang (dapur pusat) yang mengelola lebih dari 2 outlet:di Purwakarta. Kami masih terus ingin memperluas secara nasional ke kota-kota lain.</p>
	<p>FaYuFa sendiri terinspirasi dari anggota 3 anggota kelompok yang bernama Fathia, Yugha, dan Fadlan</p>
<p>FaYuFa cake & Bakery  adalah salah satu pelopor pertama dalam bisnis roti modern di Purwakarta. Didirikan pada tahun 2024, saat ini dikelola di PT. Mencari Cinta Sejati. Produk kami sehat, bergizi, dan terjangkau untuk semua orang.</p>
</div>




 <?php 
	include 'footer.php';
 ?>